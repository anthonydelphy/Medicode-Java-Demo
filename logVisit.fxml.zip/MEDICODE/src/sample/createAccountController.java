package sample;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class createAccountController {

    @FXML
    private Button createAccountButton;

    @FXML
    private Button createBack;

    @FXML
    private TextField createBirthday;

    @FXML
    private TextField createEmail;

    @FXML
    private TextField createFirstName;

    @FXML
    private TextField createLastName;

    @FXML
    private TextField createPassword;

    @FXML
    void createAccount(ActionEvent event) {
        //Logic for inputting account info

        //Verification for each field logic

    }

    @FXML
    void previousScene(ActionEvent event) {


        //Pass it it the previous scene and reload it


    }

}
